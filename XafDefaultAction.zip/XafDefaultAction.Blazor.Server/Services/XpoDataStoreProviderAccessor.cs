﻿using System;
using DevExpress.ExpressApp.Xpo;

namespace XafDefaultAction.Blazor.Server.Services {
    public class XpoDataStoreProviderAccessor {
        public IXpoDataStoreProvider DataStoreProvider { get; set; }
    }
}
