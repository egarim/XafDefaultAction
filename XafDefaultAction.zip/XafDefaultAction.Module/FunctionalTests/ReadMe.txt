﻿Folder Description

The "FunctionalTests" project folder is intended for storing EasyTest 
configuration file and scripts.


Relevant Documentation

Functional Testing
https://docs.devexpress.com/eXpressAppFramework/113206
